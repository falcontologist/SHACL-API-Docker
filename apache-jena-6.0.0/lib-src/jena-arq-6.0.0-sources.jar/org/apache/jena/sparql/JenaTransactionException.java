/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *   https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 *
 *   SPDX-License-Identifier: Apache-2.0
 */

package org.apache.jena.sparql;

import org.apache.jena.shared.JenaException ;

public class JenaTransactionException extends JenaException
{
    public JenaTransactionException()                                  { super(); }
    public JenaTransactionException(String message)                    { super(message); }
    public JenaTransactionException(Throwable cause)                   { super(cause) ; }
    public JenaTransactionException(String message, Throwable cause)   { super(message, cause) ; }
}
